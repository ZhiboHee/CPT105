package MOBA_Game;

public class Marksman extends Hero {
    //Specific attribute of Marksman.
    private double critical_Rating;

    public Marksman(String _name, int _life, int _movement_Speed, int _attack_Power, double _attack_Speed) {
        super(_name, _life, _movement_Speed, _attack_Power, _attack_Speed);
    }

    public double getCritical_Rating() {
        return critical_Rating;
    }

    public void setCritical_Rating(double newCritical_Rating) {
        critical_Rating = newCritical_Rating;
    }

    public static void burstMode() {
        //Increases attack speed by 20% for three seconds.
        System.out.println("Marksman's Skill: Burst Mode!");
    }

    public static void stunEnemy() {
        //Stun enemy heroes so they can't deal attack power for two seconds.
        System.out.println("Marksman's Skill: Stun Enemy!");
    }

    public static void imprison() {
        //Imprison the enemy and make the enemy hero's movement speed zero for two seconds.
        System.out.println("Marksman's Skill: Imprison!");
    }
}
