package MOBA_Game;

public class Fighter extends Hero {
    //Specific attribute of Fighter.
    private double armor_Points;

    public Fighter(String _name, int _life, int _movement_Speed, int _attack_Power, double _attack_Speed) {
        super(_name, _life, _movement_Speed, _attack_Power, _attack_Speed);
    }

    public double getArmor_Points() {
        return armor_Points;
    }

    public void setArmor_Points(double newArmor_Points) {
        armor_Points = newArmor_Points;
    }

    public static void Charge() {
        //Charge forward, then increase the hero's movement speed by 50% for two seconds.
        System.out.println("Fighter's Skill: Charge!");
    }

    public static void defensive_Stance() {
        //Adds 100 armor points for five seconds.
        System.out.println("Fighter's Skill: defensive Stance!");
    }

    public static void rampage() {
        //Increases attack power by 20% for three seconds.
        System.out.println("Fighter's Skill: rampage!");
    }

}
