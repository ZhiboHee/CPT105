package MOBA_Game;

public abstract class Hero {

//Problem 1)
    private String name;
    private int life;
    private int movement_Speed;
    private int attack_Power;
    //One extra attribute, which is critical to profession's skill.
    private double attack_Speed;

    public Hero(String _name, int _life, int _movement_Speed, int _attack_Power, double _attack_Speed) {
        this.name = _name;
        this.life = _life;
        this.movement_Speed = _movement_Speed;
        this.attack_Power = _attack_Power;
        this.attack_Speed = _attack_Speed;
    }

    public String getName() {
        return name;
    }

    public int getLife() {
        return life;
    }

    public int getMovement_Speed() {
        return movement_Speed;
    }

    public int getAttack_Power() {
        return attack_Power;
    }

    public double getAttack_Speed() {
        return attack_Speed;
    }

    public void setName(String newName) {
        name = newName;
    }

    public void setLife(int newLife) {
        life = newLife;
    }

    public void setMovement_Speed(int newMovement_Speed) {
        movement_Speed = newMovement_Speed;
    }

    public void setAttack_Speed(double newAttack_Speed) {
        attack_Speed = newAttack_Speed;
    }

    public void setAttack_Power(int newAttack_Power) {
        attack_Power = newAttack_Power;
    }

//Problem 3)
    public static void Flash() {
        //Teleport a short distance.
        System.out.println("shared skill: Flash!");
    }

    public static void Exhaust() {
        //Reduce the movement speed of the target hero by 30% and the attack power they deal by 40% for two seconds.
        System.out.println("shared skill: Exhaust!");
    }

    public static void main(String[] args) {
        //Object test:
        //profession 1:
        Fighter Warrior = new Fighter("Fighter.Warrior", 700, 1, 40, 0.35);

        Warrior.setArmor_Points(50);
        System.out.println("Initialize Armor Points: " + Warrior.getArmor_Points());

        System.out.println("Current Name: " + Warrior.getName());
        Warrior.setName("Fighter.Warrior prime");
        System.out.println("New Name: " + Warrior.getName());

        System.out.println("Current life: " + Warrior.getLife());
        Warrior.setLife(650);
        System.out.println("New life: " + Warrior.getLife());

        System.out.println("Current Movement Speed: " + Warrior.getMovement_Speed());
        Warrior.setMovement_Speed(2);
        System.out.println("New Movement Speed: " + Warrior.getMovement_Speed());

        System.out.println("Current Attack Power: " + Warrior.getAttack_Power());
        Warrior.setAttack_Power(50);
        System.out.println("New Attack Power: " + Warrior.getAttack_Power());

        System.out.println("Current Attack Speed: " + Warrior.getAttack_Speed());
        Warrior.setAttack_Speed(0.4);
        System.out.println("New Attack Speed: " + Warrior.getAttack_Speed());
        
        System.out.println("Current Armor Points: " + Warrior.getArmor_Points());
         Warrior.setArmor_Points(60);
        System.out.println("Initialize Armor Points: " + Warrior.getArmor_Points());

        Warrior.Flash();
        Warrior.Exhaust();
        Warrior.Charge();
        Warrior.defensive_Stance();
        Warrior.rampage();
        System.out.println();

        //profession 2:
        Marksman Lucian = new Marksman("Marksman.Lucian", 500, 2, 50, 0.75);
                
        Lucian.setCritical_Rating(0.4);
        System.out.println("Initialize Critical Rating: " + Lucian.getCritical_Rating());
        
        System.out.println("Current Name: " + Lucian.getName());
        Lucian.setName("Marksman.Lucian prime");
        System.out.println("New Name: " + Lucian.getName());
        System.out.println("Current life: " + Lucian.getLife());
        Lucian.setLife(550);
        System.out.println("New life: " + Lucian.getLife());

        System.out.println("Current Movement Speed: " + Lucian.getMovement_Speed());
        Lucian.setMovement_Speed(3);
        System.out.println("New Movement Speed: " + Lucian.getMovement_Speed());

        System.out.println("Current Attack Power: " + Lucian.getAttack_Power());
        Lucian.setAttack_Power(60);
        System.out.println("New Attack Power: " + Lucian.getAttack_Power());

        System.out.println("Current Attack Speed: " + Lucian.getAttack_Speed());
        Lucian.setAttack_Speed(0.7);
        System.out.println("New Attack Speed: " + Lucian.getAttack_Speed());

        System.out.println("Current Critical Rating: " + Lucian.getCritical_Rating());
        Lucian.setCritical_Rating(0.3);
        System.out.println("New Critical Rating: " + Lucian.getCritical_Rating());

        Lucian.Flash();
        Lucian.Exhaust();
        Lucian.burstMode();
        Lucian.stunEnemy();
        Lucian.imprison();
        System.out.println();
    }
}
