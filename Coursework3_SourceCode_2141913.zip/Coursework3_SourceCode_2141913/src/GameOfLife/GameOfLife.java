package GameOfLife;

import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import java.util.HashMap;

public class GameOfLife {

    public static int[][] state = {
        {0, 1, 0, 0, 0},
        {0, 0, 1, 0, 0},
        {1, 1, 1, 0, 0},
        {0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0}};
    public static int n = 103;
    public static HashMap<String, Integer> count = new HashMap<String, Integer>();

    private static int[] coordinate(int x, int y) {

        int cor[] = {x, y};
        if (x == -1) {
            cor[0] = 4;
        }
        if (y == -1) {
            cor[1] = 4;
        }
        if (x == 5) {
            cor[0] = 0;
        }
        if (y == 5) {
            cor[1] = 0;
        }
        return cor;
    }

//Problem 1: 
    public static int returnAlive(int x, int y) {
        int coor[] = new int[2];
        int sum = 0;
        //above, below, left, right, top left, bottom left, top right and bottom right of a cell
        coor = coordinate(x - 1, y - 1);
        sum += state[coor[0]][coor[1]];

        coor = coordinate(x, y - 1);
        sum += state[coor[0]][coor[1]];

        coor = coordinate(x + 1, y - 1);
        sum += state[coor[0]][coor[1]];

        coor = coordinate(x - 1, y);
        sum += state[coor[0]][coor[1]];

        coor = coordinate(x + 1, y);
        sum += state[coor[0]][coor[1]];

        coor = coordinate(x - 1, y + 1);
        sum += state[coor[0]][coor[1]];

        coor = coordinate(x, y + 1);
        sum += state[coor[0]][coor[1]];

        coor = coordinate(x + 1, y + 1);
        sum += state[coor[0]][coor[1]];

        return sum;
    }

//Problem 2: 
    public static void goNextState() {
        int[][] tempState = new int[5][5];
        int aliveNums = 0;

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                aliveNums = returnAlive(i, j);
                if (state[i][j] == 1) {
                    if (aliveNums == 2 || aliveNums == 3) {
                        tempState[i][j] = 1;
                    } else if (aliveNums < 2 || aliveNums > 3) {
                        tempState[i][j] = 0;
                    }
                } else if (state[i][j] == 0) {
                    if (aliveNums == 3) {
                        tempState[i][j] = 1;
                    }
                }
            }
        }
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                state[i][j] = tempState[i][j];
            }
        }
    }
    
//Problem 5: 
    public static void printState(int[][] intput) {
        String stateStr = "";
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(state[i][j]);
            }
            System.out.println();
        }
    }
    
//Problem 3:
    public static String getStateStr() {
        String stateStr = "";
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                stateStr = stateStr + state[i][j];
            }
        }
        return stateStr;
    }

    public static int[][] strToState(String str) {
        int tempState[][] = new int[5][5];
        int k = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (Character.isDigit(str.charAt(k))) {
                    tempState[i][j] = Integer.parseInt(str.valueOf(str.charAt(k)));
                }
                k++;
            }
        }
        return tempState;
    }
    
//Problem 4:
    public static boolean checkStateStr(String str) {
        boolean strValid = false;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == '1') {
                strValid = true;
                break;
            }
        }
        return strValid;
    }
    
//Problem 6:
    public static void main(String[] args) {
        String maxKey = "";
        int maxValue = 0;

        for (int i = 0; i < n; i++) {
            goNextState();
            if (!checkStateStr(getStateStr())) {
                break;
            }
            if (count.containsKey(getStateStr())) {
                count.replace(getStateStr(), count.get(getStateStr()) + 1);
            } else {
                count.put(getStateStr(), 1);
            }
        }

        if (count.size() > 1) {
            Set<Map.Entry<String, Integer>> countSet = count.entrySet();
            for (Iterator<Map.Entry<String, Integer>> iterator = countSet.iterator(); iterator.hasNext();) {
                Map.Entry<String, Integer> entry = (Map.Entry<String, Integer>) iterator.next();
                String key = entry.getKey();
                Integer value = entry.getValue();

                if (value > maxValue) {
                    maxValue = value;
                    maxKey = key;
                }
            }
            System.out.println(maxValue);
            printState(strToState(maxKey));
        } else {
            System.out.println(count.size());
            for (int k = 0; k < 5; k++) {
                for (int p = 0; p < 5; p++) {
                    System.out.print("0");
                }
                System.out.println();
            }
        }
    }
}
