package NodeListTree;

public class NodeList {

    public String value;
    public NodeList next;

    public NodeList(String _value, NodeList _next) {
        value = _value;
        next = _next;
    }

    public NodeList(String _value) {
        value = _value;
        next = null;
    }
}
