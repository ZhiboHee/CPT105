package NodeListTree;

import org.w3c.dom.Node;
import NodeListTree.NodeList;
import java.util.HashMap;

public class NodeListTree {

    public NodeList val;
    public NodeListTree left, right;

//Problem 1: 
 public NodeListTree(NodeList _val, NodeListTree _left, NodeListTree _right) {
        this.val = _val;
        this.left = _left;
        this.right = _right;
    }

    public NodeListTree(NodeList _val) {
        this.val = _val;
        this.left = null;
        this.right = null;
    }

//Problem 3: 
    public static String printFirst(NodeListTree root) {
        String firstStr = "";

        if (root == null) {
            return null;
        }

        String retval[] = root.val.value.split("->", 2);
        firstStr = retval[0] + firstStr;

        if (root.left == null && root.right == null) {
            return firstStr;
        }

        if (root.left != null) {
            firstStr = firstStr + printFirst(root.left);
        }

        if (root.right != null) {
            firstStr = firstStr + printFirst(root.right);
        }
        return firstStr;
    }

//Problem 4: 
    public static String printSecond(NodeListTree root) {
        String secondStr = "";

        if (root == null) {
            return null;
        }

        if (root.left != null) {
            secondStr = secondStr + printSecond(root.left);
        }

        String retval[] = root.val.value.split("->", 2);
        secondStr = secondStr + retval[1];

        if (root.right != null) {
            secondStr = secondStr + printSecond(root.right);
        }

        if (root.left == null && root.right == null) {
            return secondStr;
        }
        return secondStr;
    }

//Problem 5:
    public static int returnAns(NodeListTree root, char aim) {
        int nums = 0;

        for (int i = 0; i < printFirst(root).length(); i++) {
            if (printFirst(root).toLowerCase().charAt(i) == Character.toLowerCase(aim)) {
                nums++;
            }
        }
        for (int i = 0; i < printSecond(root).length(); i++) {
            if (printSecond(root).toLowerCase().charAt(i) == Character.toLowerCase(aim)) {
                nums++;
            }
        }
        return nums;
    }
    
//Problem 2:
    public static void main(String[] args) {

        NodeListTree F = new NodeListTree(new NodeList("F->Course"));
        NodeListTree E = new NodeListTree(new NodeList("E->This"));
        NodeListTree D = new NodeListTree(new NodeList("D->To"));
        NodeListTree C = new NodeListTree(new NodeList("C->Welcome"), null, F);
        NodeListTree B = new NodeListTree(new NodeList("B->Everyone"), D, E);
        NodeListTree A = new NodeListTree(new NodeList("A->Hello"), B, C);

        System.out.println(printFirst(A));
        System.out.println(printSecond(A));
        System.out.println(returnAns(A, 'c'));
    }
}
